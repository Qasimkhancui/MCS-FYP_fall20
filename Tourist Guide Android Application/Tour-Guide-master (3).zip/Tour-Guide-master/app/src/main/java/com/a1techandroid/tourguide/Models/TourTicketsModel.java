package com.a1techandroid.tourguide.Models;

public class TourTicketsModel {
}
